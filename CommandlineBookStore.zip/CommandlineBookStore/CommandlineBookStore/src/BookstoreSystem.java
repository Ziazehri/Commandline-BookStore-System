import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

//Class Book represents books in the cart
 class Book
{
    public  String ISBN;
    public String title;
    public  String author;
    public  double price;
    public  int copiesAvailable;

    public Book(String ISBN, String title, String author, double price, int copiesAvailable) 
    {
        this.ISBN = ISBN;
        this.title = title;
        this.author = author;
        this.price = price;
        this.copiesAvailable = copiesAvailable;
    }
    //Getters and setters
    public String getISBN() {
        return ISBN;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor()
     {
        return author;
    }

    public double getPrice()
     {
        return price;
    }

    public int getCopiesAvailable() 
    {
        return copiesAvailable;
    }
      
    //Method to uplod inventory
    public void updateInventory(int quantity)
    {
        if (quantity <= copiesAvailable) 
        {
            copiesAvailable -= quantity;
        } else
         {
            System.out.println("Not enough copies available.");
        }
    }
        //Method to display book info
    public void displayBookInfo()
    {
        System.out.println("\n Result");
        System.out.println("ISBN: " + ISBN);
        System.out.println("Title: " + title);
        System.out.println("Author: " + author);
        System.out.println("Price: $" + price);
        System.out.println("Copies Available: " + copiesAvailable);}

    }

    // Class Represent the shoping cart
 class Cart {
    private List<Book> booksInCart;
    private List<Integer> quantities;
    private double totalCost;

    public Cart() {
        this.booksInCart = new ArrayList<>();
        this.quantities = new ArrayList<>();
        this.totalCost = 0.0;
    }

    public  List<Book> getBooksInCart(){
        return booksInCart;
      }
    //Method to add a book to the cart
    public void addBook(Book book, int quantity) {
        if (book.getCopiesAvailable() >= quantity) {
            int index = booksInCart.indexOf(book);
            if (index >= 0) {
                // If the book is already in the cart, update the quantity
                int newQuantity = quantities.get(index) + quantity;
                quantities.set(index, newQuantity);
            } else {
                // If the book is not in the cart, add it to the cart
                booksInCart.add(book);
                quantities.add(quantity);
            }
            totalCost += book.getPrice() * quantity;
            book.updateInventory(quantity);
        } else {
            System.out.println("Not enough copies available.");
        }
    }
      //Method to remove a book fron the cart 
    public void removeBook(Book book, int quantity) {
        int index = booksInCart.indexOf(book);
        if (index >= 0) {
            int currentQuantity = quantities.get(index);
            if (currentQuantity <= quantity) {
                totalCost -= book.getPrice() * currentQuantity;
                booksInCart.remove(index);
                quantities.remove(index);
            } else {
                quantities.set(index, currentQuantity - quantity);
                totalCost -= book.getPrice() * quantity;
            }
            book.updateInventory(quantity);  // Adding back to inventory
        } else {
            System.out.println("Book not in cart.");
        }
    }
       //Method to calculate total cost
    public double calculateTotal() {
        return totalCost;
    }
       //Method to display cart contents
    public void displayCart() {
        System.out.println("Your Cart:");
        for (int i = 0; i < booksInCart.size(); i++) {
            Book book = booksInCart.get(i);
            int quantity = quantities.get(i);
            System.out.println(book.getTitle() + " - Quantity: " + quantity + " - Price: $" + book.getPrice());
        }
        System.out.println("Total Cost: $" + totalCost);
    }

    /**
     * 
     */

      //Method to clear the cart after the checkout
    public void checkout()
     {
        if (booksInCart.isEmpty()) 
        {
            System.out.println("Your cart is empty.");
        } else 
        {
            System.out.println("Checkout successful. Thank you for your purchase!");
            booksInCart.clear();
            quantities.clear();
            totalCost = 0.0;}
        }}

        //Class to handel inventory and shopping process.
 class Store
{
    private List<Book> inventory;

    public Store() {
        this.inventory = new ArrayList<>();
    }
    public  List<Book> getInventory(){
        return inventory;
      }
       //Method to add a book to the inventory
    public void addBookToInventory(Book book) {
        inventory.add(book);
    }
       //Methods to search a book by ISBN ,title, or author
    public void searchBookByISBN(String ISBN) {
        for (Book book : inventory) {
            if (book.getISBN().equals(ISBN)) {
                book.displayBookInfo();
                return;
            }
        }
        System.out.println("Book not found.");
    }

    public void searchBookByTitle(String title) {
        for (Book book : inventory) {
            if (book.getTitle().equalsIgnoreCase(title)) {
                book.displayBookInfo();
                return;
            }
        }
        System.out.println("Book not found.");
    }

    public void searchBookByAuthor(String author) {
        for (Book book : inventory) {
            if (book.getAuthor().equalsIgnoreCase(author)) {
                book.displayBookInfo();
                return;
            }
        }
        System.out.println("Book not found.");
    }
       
     //Method to display available books 
    public void displayAvailableBooks() {
        System.out.println("Available Books:");
        for (Book book : inventory) {
            book.displayBookInfo();
            System.out.println();
        }
    }
}

// Main class ( or Entry point ) and the command line interface 
public class BookstoreSystem
{
      public static void main(String[] args)
       {
        Store store = new Store();
        Cart cart = new Cart();
        Scanner scanner = new Scanner(System.in);

        // added some books to the inventory 
        store.addBookToInventory(new Book("1111", "Namal", "Nimre", 499.99, 10));
        store.addBookToInventory(new Book("2222", "Jannat-ke-patte", "Umaira Ahmed", 699.99, 5));
        store.addBookToInventory(new Book("2233", "Haya", "Umaira Ahmed", 299.99, 5));
        store.addBookToInventory(new Book("2244", "Java by DS Malik", "Ds Malik", 899.99, 5));

        while (true)
         {
            System.out.println("\nWelcome to the Command Line Bookstore");
            System.out.println("1. View all books");
            System.out.println("2. Search book by ISBN");
            System.out.println("3. Search book by title");
            System.out.println("4. Search book by author");
            System.out.println("5. Add book to cart");
            System.out.println("6. Remove book from cart");
            System.out.println("7. View cart");
            System.out.println("8. Checkout");
            System.out.println("9. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine();  // creates newline

            switch (choice)
             {
                case 1:
                    store.displayAvailableBooks();
                    break;
                case 2:
                    System.out.print("Enter ISBN: ");
                    String isbn = scanner.nextLine();
                    store.searchBookByISBN(isbn);
                    break;
                case 3:
                    System.out.print("Enter title: ");
                    String title = scanner.nextLine();
                    store.searchBookByTitle(title);
                    break;
                case 4:
                    System.out.print("Enter author: ");
                    String author = scanner.nextLine();
                    store.searchBookByAuthor(author);
                    break;
                case 5:
                    System.out.print("Enter ISBN of the book to add: ");
                    isbn = scanner.nextLine();
                    for (Book book : store.getInventory()) {
                        if (book.getISBN().equals(isbn)) {
                            System.out.print("Enter quantity: ");
                            int quantity = scanner.nextInt();
                            cart.addBook(book, quantity);
                            break;
                        }
                    }
                    break;
                case 6:
                    System.out.print("Enter ISBN of the book to remove: ");
                    isbn = scanner.nextLine();
                    for (Book book : cart.getBooksInCart()) {
                        if (book.getISBN().equals(isbn)) {
                            System.out.print("Enter quantity: ");
                            int quantity = scanner.nextInt();
                            cart.removeBook(book, quantity);
                            break;
                        }
                    }
                    break;
                case 7:
                    cart.displayCart();
                    break;
                case 8:
                    cart.checkout();
                    break;
                case 9:
                    System.out.println("Exiting the bookstore. Have a great day!");
                    scanner.close();
                    System.exit(0);
                default:
                    System.out.println("Invalid choice, please try again.");
            }
        }
        
        }
        }
